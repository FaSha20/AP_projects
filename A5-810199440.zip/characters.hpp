#ifndef _CHARACTER_H
#define _CHARACTER_H

#define  WINDOW_SIZE Point(640,1024)
#define  JUMPER_SIZE Point(124,120)
const int VERTICAL_VELOCITY = -40;
const int HORIZENTAL_VELOCITY = 10;
const int GRAVITY_FACTOR = 2;
#include <iostream>
#include <string>
#include <vector>
#include "../src/rsdl.hpp"
#include "characters.hpp"
using namespace std;
class Jumper;
class Entity;


struct Score_range
{
    int start;
    int end;
};


class Camera{
public:
   Camera(){height = 0 ;};
   void move_up(Jumper* jumper);
   int get_height(){return height;};
private:
   int height;
};

class Jumper{
 public:
   Jumper(Point pos);
   void update_loc(int h_speed);
   Point get_loc(){return location;};
   int calc_total_score(Camera* cam);
   bool is_higher_than_half_window(Camera* cam);
   void set_vertical_speed(int speed);
   string face_side ;
   string dir;
   string status; 
   
 private:
    Point location;
    int v_speed;
    int top_score;
};



class Entity{
public:
   Entity(Point _loc){location = _loc;};
   void draw(Camera* cam,Window* win,int total_height);
   string get_type(){return type;}; 
   bool is_in_this_location(Point loc,int total_h); 
   virtual void react(Jumper* jumper,
                     Camera* cam,Window* win,int total_h) = 0;
protected:
   Point location;
   Point size;
   string type ;
};

class Platform : public Entity{
public:
   Platform(Point _loc) :Entity(_loc)
      {size = Point(120,36),type = "platform";};
   void react(Jumper* jumper,Camera* cam,Window* win,int total_h);
      
protected:

};

class M_Platform : public Platform{
public:
   M_Platform(Point _loc):Platform(_loc)
      {size = Point(120,36), type = "mplatform",direction = 1;};
   int direction ;
   void move_horizentaly();
};

class B_Platform : public Platform{
public:
   B_Platform(Point _loc):Platform(_loc)
      {size = Point(120,36), type = "bplatform";};
   void react(Jumper* jumper,Camera* cam,Window* win,int total_h);
   void draw_breaking(Camera* cam,Window* win,int total_h);
private: 
};

class Enemy : public Entity{
public:
   Enemy(Point _loc): Entity(_loc){size = Point(136,184),type = "enemy";};
   void react(Jumper* jumper,Camera* cam,Window* win,int total_h);      
private: 
};

class Spring : public Entity{
public:
   Spring(Point _loc): Entity(_loc){size = Point(56,46),type = "spring";};
   void react(Jumper* jumper,Camera* cam,Window* win,int total_h)
      {jumper->set_vertical_speed(1.5 * VERTICAL_VELOCITY);};
private: 
};

struct Ent_lists{
   vector <M_Platform*> mps;
   vector <B_Platform*> bps;
   vector <Platform*> ps;
   vector <Enemy*> ens;
   vector <Spring*> sps;
   vector <Entity*> entities;
};

class Sequence{
public:
   Sequence(Score_range _range,int _height){range = _range, total_height = _height;};
   void add_entity(Entity* new_ent)
   {ent_list.entities.push_back(new_ent);};
   bool is_score_in_my_range(int score);
   Score_range range;
   Ent_lists ent_list{};
   int total_height;
private:
};


#endif //_CHARACTER_H