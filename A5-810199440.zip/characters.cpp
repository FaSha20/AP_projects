#include <iostream>
#include "../src/rsdl.hpp"
#include "characters.hpp"
#include <string>
#include <cmath>
using namespace std;


Jumper::Jumper(Point pos){
    location = pos;
    face_side ="left";
    v_speed = VERTICAL_VELOCITY;
    top_score = 0;
    dir = "up";
    status = "gaming";

}
void Jumper::update_loc(int h_speed){
    location.x += h_speed;
    v_speed += GRAVITY_FACTOR ;
    if(v_speed >= 0){
        dir = "down";
        cout << dir;
    }
        
    else{
        dir = "up";
        cout << dir;
    }
        
    location.y += (v_speed);
   
}

void Jumper::set_vertical_speed(int speed){
    v_speed = speed;
}


int Jumper:: calc_total_score(Camera* cam){
    while(top_score < cam->get_height()){
        top_score +=5;
        return top_score;
    }
}

bool Jumper:: is_higher_than_half_window(Camera* cam){
    if( abs(location.y + cam->get_height()) > WINDOW_SIZE.y/2 )
        return true;
    else 
        return false;        
}

void Camera:: move_up(Jumper* jumper)
{
   if(jumper->dir == "up" ){
       cout << "move up camera\n\n";
       height = abs( jumper->get_loc().y - WINDOW_SIZE.y/2);
   }
        

}

void Entity:: draw(Camera* cam,Window* win,int total_h)
{
    Point cam_loc(0,cam->get_height());
    win->draw_img("assets/main pictures/" + type + ".png",
        Rectangle(location + cam_loc - Point(0,total_h) 
                  ,location + cam_loc- Point(0,total_h) + size)); 
    cout << "draw entitiy\n\n " << total_h << endl;  

}

bool Entity::is_in_this_location(Point loc,int total_h)
{
    Point ent_real_loc = location - Point(0,total_h);
    if( abs(loc.y - ent_real_loc.y) <= 30 
     && abs(loc.x - ent_real_loc.x) <= 30 ){
        return true;
    }
    else
        return false;
}
void Platform:: react(Jumper* jumper,Camera* cam,Window* win,int total_h)
{
    jumper->set_vertical_speed(VERTICAL_VELOCITY);
}


void M_Platform::move_horizentaly()
{
    if(location.x >= WINDOW_SIZE.x)
        direction = -1;
    if(location.x <= 0)
        direction = 1;
    location.x += direction * HORIZENTAL_VELOCITY;
}
void B_Platform::react(Jumper* jumper,Camera* cam,Window* win,int total_h)
{
    win->play_sound_effect("assets/main pictures/break.wav");
    draw_breaking(cam,win,total_h);
}

void B_Platform::draw_breaking(Camera* cam,Window* win,int total_h)
{
    Point cam_loc(0,cam->get_height());
    location = location + Point(0,total_h);
    win->draw_img("assets/main pictures/bplatform2.png",
        Rectangle(location + cam_loc  ,location + cam_loc + size));
    win->draw_img("assets/main pictures/bplatform3.png",
        Rectangle(location + cam_loc  ,location + cam_loc + size));
    win->draw_img("assets/main pictures/bplatform4.png",
        Rectangle(location + cam_loc  ,location + cam_loc + size));
    win->update_screen();
}

void Enemy::react(Jumper* jumper,Camera* cam,Window* win,int total_h)
{
    win->play_sound_effect("assets/main pictures/enemy.wav");
    jumper->status = "game over";
}

bool Sequence::is_score_in_my_range(int score)
{
    if(score >= range.start ){
        if(score <= range.end || range.end == -1)
            return true;
    }
    return false;
}


