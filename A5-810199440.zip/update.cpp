#include <iostream>
#include "../src/rsdl.hpp"
#include "characters.hpp"
#include "update.hpp"
#include <time.h>
#include <string>
using namespace std;


bool is_out_of_window(Jumper* jumper,Camera* cam)
{
    if(jumper->get_loc().y - cam->get_height() > WINDOW_SIZE.y )
        return true;  
    else   
        return false;                                                   
}

void check_losing(Window* win,Jumper* jumper,Camera* cam)
{
    if(jumper->status == "game over" && win->has_pending_event()){
        Event last_event = win->poll_for_event();
        if(last_event.get_type() == Event::KEY_PRESS)
                exit(0); 
    }
    if(is_out_of_window(jumper,cam)){
         jumper->status = "game over"; 
    }
}

void check_events(Window* win,Jumper* jumper)
{
    while(win->has_pending_event()){
        Event event = win->poll_for_event();
        switch(event.get_type()){
            case Event::EventType::QUIT:
                jumper->status = "exit";
                break;
            case Event::KEY_PRESS:
                 if (event.get_pressed_key() == RIGHT_KEY){
                    jumper->update_loc(HORIZENTAL_TRANSMITION);
                    jumper->face_side = "right";
                 }
                 else if(event.get_pressed_key() == UP_KEY){
                    jumper->face_side = "up";
                 }
                 else if(event.get_pressed_key() == LEFT_KEY){
                    jumper->update_loc(-1 * HORIZENTAL_TRANSMITION);
                    jumper->face_side = "left";
                 }
            default:;
        }
    }
}

Entity* find_impacted_entity(Jumper* jumper,vector<Entity*>entities,int total_h)
{
    for(int i=0 ; i < entities.size() ;i++){
        if(entities[i]->is_in_this_location(jumper->get_loc() , total_h) && jumper->dir == "down"){
            cout << entities[i]->get_type() << endl;
            return entities[i];
        }    
    }
    return NULL;
}

void check_collision(Window* win,Jumper* jumper,
                     Camera* camera, Sequence* plan,int total_h)
{
    if(jumper->dir == "down"){
        Entity* impacted_item = 
            find_impacted_entity(jumper,plan->ent_list.entities,total_h);
        if(impacted_item != NULL)
            impacted_item -> react(jumper,camera,win,total_h);    
    }   
}

void update_jumper(Jumper* jumper)
{
    jumper->update_loc(JUST_VERTICAL_TRANSMITION);
    if(jumper->get_loc().x > WINDOW_SIZE.x )
        jumper->update_loc(-1 * WINDOW_SIZE.x);
    if(jumper->get_loc().x < 0 )
        jumper->update_loc(WINDOW_SIZE.x);
}

void update_camera(Camera* cam,Jumper* jumper)
{
    if(jumper->is_higher_than_half_window(cam)){
        cout << "higher    \n";
        cam->move_up(jumper);
    }
       
}

void update_entities(Ent_lists ent_list)
{
    for(int i=0; i< ent_list.mps.size();i++)
       ent_list.mps[i]->move_horizentaly();
    
    
}

Sequence* make_plan(Jumper* jumper,Camera* camera
        ,vector <Sequence*> sequences)
{
    int score = jumper->calc_total_score(camera);
    srand(time(0));
    vector <Sequence*> good_sequs;
    for(int s = 0; s < sequences.size(); s++){
        if(sequences[s]->is_score_in_my_range(score))
            good_sequs.push_back(sequences[s]);
    }
    int random_index = rand() % good_sequs.size();
    return good_sequs[random_index];
}

void exit_game(Window* win)
{
  while(true){
    Event event = win->poll_for_event();
    if(event.get_type() == Event::QUIT || 
       event.get_type() == Event::KEY_PRESS)
    exit(0);
  }
}