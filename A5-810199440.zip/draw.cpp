#include <iostream>
#include "../src/rsdl.hpp"
#include "characters.hpp"
#include "draw.hpp"
#include <string>
using namespace std;
int just_one_time = 0;

void draw_basic_items(Window* win,Jumper* jumper,Camera* camera)
{
    win->draw_img("assets/main pictures/background.png");
    win->draw_img("assets/main pictures/top_score.png",
        Rectangle(Point(0,0),Point(WINDOW_SIZE.x,80)));
    win->show_text(to_string(jumper->calc_total_score(camera)),Point(2,2),
        WHITE,"assets/main pictures/OpenSans.ttf",50);  
    
}

void draw_plan(Sequence* plan,Camera* cam,Window* win,int total_h)
{
    for(int i = 0; i < plan->ent_list.entities.size(); i++){
        plan->ent_list.entities[i]->draw(cam,win,total_h);
    }
}

void draw_main_window(Window* win,Jumper* jumper,Camera* camera
                        ,Sequence* plan,int total_h)
{
    Point cam_loc(0,camera->get_height());
    draw_basic_items(win,jumper,camera);
    draw_plan(plan,camera,win,total_h);

    win->draw_img("assets/main pictures/" + jumper->face_side +".png",
         Rectangle(jumper->get_loc() + cam_loc ,
                   jumper->get_loc()+ JUMPER_SIZE + cam_loc ));
}

void draw_end_window(Window* win,Jumper* jumper,Camera* cam)
{
    win->clear();
    for(just_one_time ; just_one_time < 1;just_one_time++)
        win->play_sound_effect("assets/main pictures/losing.mp3");
    win->draw_img("assets/main pictures/Default.png");
    win->draw_img("assets/main pictures/gameover2.png",
        Rectangle(Point(20, 2*(WINDOW_SIZE.y)/3),WINDOW_SIZE));   
    win->draw_img("assets/main pictures/score.png",
        Rectangle(Point(50,600),Point(350,700)));
    win->show_text(to_string(cam->get_height()),Point(365,600)
         ,BLACK,"assets/main pictures/OpenSans.ttf",54);
}