#include <iostream>
#include "../src/rsdl.hpp"
#include "characters.hpp"
#include "read_file.hpp"
#include <string>
#include <vector>
#include <fstream>

using namespace std;

Entity* find_make_type(string type, Point location,Ent_lists& ent_list){
    if(type == "platform"){
        Platform* new_ent = new Platform(location);
        ent_list.ps.push_back(new_ent);
        return new_ent;
    }
    else if (type == "mplatform"){
        M_Platform* new_ent = new M_Platform(location);
        ent_list.mps.push_back(new_ent);
        return new_ent;
    }  
    else if (type == "bplatform"){
        B_Platform* new_ent = new B_Platform(location);
        ent_list.bps.push_back(new_ent);
        return new_ent;
    }
    else if (type == "enemy"){
        Enemy* new_ent = new Enemy(location);
        ent_list.ens.push_back(new_ent);
        return new_ent;
    }
    else if (type == "spring"){
        Spring* new_ent = new Spring(location);
        ent_list.sps.push_back(new_ent);
        return new_ent;
    } 
    else
        return NULL; 
}

vector <Sequence*> read_sequence_file()
{
    vector <Sequence*> sequs;
    int num_of_sequs,num_of_ents;
    int height,start_score,end_score;
    string type;
    Point location;
    fstream input(SEQUENCE_FILE);
    input >> num_of_sequs;
    
    for(int s = 0; s < num_of_sequs; s++){
        input >> start_score >> end_score >> height >> num_of_ents;
        Sequence* new_seq = new Sequence
                (Score_range{start_score,end_score},height );
        for(int e = 0; e < num_of_ents; e++){
            input >> location.x >> location.y >> type;
            Entity* new_ent = find_make_type(type,location,new_seq->ent_list);
            new_seq->add_entity(new_ent);
        }
        sequs.push_back(new_seq);
    }
    input.close();
    return sequs;
}

