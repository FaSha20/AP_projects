#ifndef _READ_FILE_H
#define _READ_FILE_H

#include <iostream>
#include "../src/rsdl.hpp"
#include "characters.hpp"
#include "read_file.hpp"
#include <string>
#include <vector>
#define  SEQUENCE_FILE "sequence.txt"

using namespace std;
vector<Sequence*> read_sequence_file();

#endif // _READ_FILE_H