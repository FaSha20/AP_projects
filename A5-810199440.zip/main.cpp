#include <iostream>
#include "../src/rsdl.hpp"
#include "characters.hpp"
#include "draw.hpp"
#include "update.hpp"
#include "read_file.hpp"
using namespace std;


void update(Window* win,Jumper* jumper,Camera* camera,
            vector <Sequence*> sequences,Sequence** plan,int& total_h)
{
    if( camera->get_height() > total_h ){
        *plan = make_plan(jumper,camera,sequences);
        cout << "\ncamera height : "<< camera->get_height() << endl;
        total_h += (*plan)->total_height;
    }
    // cout << plan->range.start << " " << (*plan)->range.end<< endl;
    // cout << total_h << endl;
    check_losing(win,jumper,camera);
    check_events(win,jumper);
    check_collision(win,jumper,camera,*plan,total_h-(*plan)->total_height);
    update_camera(camera,jumper);
    update_jumper(jumper);
    update_entities((*plan)->ent_list);
}

void draw(Window* win,Jumper* jumper,Camera* camera,
        Sequence* plan,int total_h)
{
    cout << "new plan height : "<<plan->total_height << endl;
    win->clear();
    draw_main_window(win,jumper,camera,plan,total_h-plan->total_height);
    if(jumper->status == "game over"){
        draw_end_window(win,jumper,camera);
        jumper->status= "exit";
    }
    win->update_screen();
}

void wait()
{ 
    delay(15);
}

int main()
{
    Window* w = new Window(WINDOW_SIZE.x,WINDOW_SIZE.y,"Doodle Jump");   
    Jumper jumper(Point(WINDOW_SIZE.x/2, WINDOW_SIZE.y/2));
    Camera camera;
    Sequence* plan;
    vector <Sequence*> sequences = read_sequence_file();

    plan = make_plan(&jumper,&camera,sequences);
    int total_h = plan->total_height;
   
    while( jumper.status != "exit"){
        update(w,&jumper,&camera,sequences,&plan,total_h);
        draw(w,&jumper,&camera,plan,total_h);
        wait();
    }
    exit_game(w);   
    return 0;
}