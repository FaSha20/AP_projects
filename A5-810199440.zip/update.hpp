#ifndef _UPDATE_H
#define _UPDATE_H

#include <iostream>
#include "../src/rsdl.hpp"
#include "characters.hpp"
#include "update.hpp"
#include <vector>
#include <string>
using namespace std;
const char RIGHT_KEY = 'd';
const char LEFT_KEY = 'a';
const char UP_KEY = 'w';
const char ENTER_KEY = ' ';
const int JUST_VERTICAL_TRANSMITION = 0;
const int HORIZENTAL_TRANSMITION = 50;


void check_losing(Window* win,Jumper* jumper,Camera* cam);
void check_events(Window* win,Jumper* jumper);
void check_collision(Window* win,Jumper* jumper, Camera* camera,
                     Sequence* plan,int total_h);
void update_entities(Ent_lists ent_list);
void update_jumper(Jumper* jumper);
void update_camera(Camera* cam,Jumper* jumper);
Sequence* make_plan(Jumper* jumper,Camera* camera,
                     vector <Sequence*> sequences);
void exit_game(Window* win);


#endif // _UPDATE_H