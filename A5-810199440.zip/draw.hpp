#ifndef _DRAW_H
#define _DRAW_H

#define  WINDOW_SIZE Point(640,1024)
#define  JUMPER_SIZE Point(124,120)
#include <iostream>
#include <string>
#include "../src/rsdl.hpp"
#include "characters.hpp"
#include "draw.hpp"
using namespace std;

void draw_main_window(Window* win,Jumper* jumper,Camera* camera
                    ,Sequence* plan,int total_h);
void draw_end_window(Window* win,Jumper* jumper,Camera* camera);


#endif //_DRAW_H