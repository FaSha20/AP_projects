//In The Name Of ALLAH//
//Random deliveries ; 1399/12/15 ; fatemeh shahhosseini//
#include <iostream>
#include <vector>
#include <stdlib.h>
#include <time.h>
#include <string>
#include <random>
const int GRP_MEMBERS = 3;;
using namespace std;


void GetStudentNames(vector <vector <string>>&  list1, int grp_num)
{
	string name;
	for (int i = 0; i < grp_num; i++) {
		for (int j = 0; j < GRP_MEMBERS; j++) {
			cin >> name;
			list1[i].push_back(name);
		}
	}
}


bool CheckDuplicateDelivery(int rnd_num, vector<int>& list)
{
	int is_duplicate = 0; unsigned int i;
	for (i = 0; i < list.size(); i++) {
		if (list[i] == rnd_num) {
			is_duplicate = 1;
			break;
		}
	}
	if (is_duplicate == 1)
		return false;
	else
		return true;
}

bool CheckDuplicateRoom(vector <vector<int>>& usedRoom_list, int firsEl, int secondEl)
{
	int is_used = 0; unsigned int i;
	vector <int> test{ firsEl,secondEl };
	for (i = 0; i < usedRoom_list.size(); i++) {
		if (usedRoom_list[i] == test) {
			is_used = 1;
			break;
		}
	}
	if (is_used == 1)
		return false;
	else
		return true;
}


int random(int max)
{
	srand((unsigned)time(0));
	return rand() % max;
}

vector <int> FirstElements(vector <string> list, vector <vector <string>>&  list1)
{
	vector <int> first_els;
	unsigned int i, j, k;
	for (i = 0; i < list1.size(); i++) {
		for (j = 0; j < list1[0].size(); j++) {
			for (k = 0; k < list.size(); k++) {
				if (list1[i][j] == list[k])
					first_els.push_back(i);
			}
		}
	}
	return first_els;
}

void Setlist1Inlist2Randomly(vector <vector <string>>& list1, vector <vector <string>>& list2)
{
	vector <int>  rndDelNum_list;
	vector <vector<int>> usedRoom_list;
	int asg, del;
	int asg_num = list2.size(), del_num = list2[0].size(), grp_num = list1.size();
	for (int i = 0; i < grp_num; i++) {
		rndDelNum_list.clear();
		for (int j = 0; j < GRP_MEMBERS; j++) {
			while (true) {
				asg = random(asg_num);
				del = random(del_num);
				if (CheckDuplicateDelivery(asg, rndDelNum_list) == true && CheckDuplicateRoom(usedRoom_list, asg, del) == true) {
					list2[asg][del] = list1[i][j];
					usedRoom_list.push_back({ asg,del });
					rndDelNum_list.push_back(asg);
					break;
				}
				else continue;
			}
		}
	}
}

void FillRemainedRoomsRandomly(vector <vector <string>>&  list1, vector <vector <string>>&  list2)
{
	vector <int> FirstEl_list;
	int i, j; unsigned int asg, del;
	for (asg = 0; asg < list2.size(); asg++) {
		FirstEl_list = FirstElements(list2[asg], list1);
		for (del = 0; del < list2[0].size(); del++) {
			if (list2[asg][del] == "") {
				while (true) {
					i = random(list1.size());
					j = random(list1[0].size());
					if (CheckDuplicateDelivery(i, FirstEl_list) == true) {
						list2[asg][del] = list1[i][j];
						FirstEl_list.push_back(i);
						break;
					}
					else continue;
				}
			}
		}
	}
}


void printList(vector <vector<string>>& list, int asg, int del)
{
	unsigned int i, j;
	cout << endl << endl;
	for (i = 0; i < list.size(); i++) {
		for (j = 0; j < list[0].size(); j++) {
			if (list[i][j] == "")
				cout << "    ";
			else
				cout << list[i][j] << " ";
		}
		cout << endl;
	}
	cout << endl << endl;
}


int main()
{
	int grp_num, asg_num, del_num;
	cin >> grp_num >> asg_num >> del_num;

	vector <vector <string>>  list1(grp_num);
	vector <vector<string>>  list2(asg_num);
	for (int i = 0; i < asg_num; i++)
		list2[i] = vector<string>(del_num);

	GetStudentNames(list1, grp_num);

	Setlist1Inlist2Randomly(list1, list2);

	FillRemainedRoomsRandomly(list1, list2);

	printList(list2, asg_num, del_num);

	return 0;
}

