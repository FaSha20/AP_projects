#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <time.h>
const int UNSATISFIED = 0;
const int SATISFIED = 1;
const int UNKNOWN = 2;
const int BIG_NUMBER = 100;
const int TILL_GENERAL_SATISFACTION = 0;
const int MAX_PIX_VAL = 255;

using namespace std;

typedef struct agant {
	int id_number;
	char color;
	int satisfaction;
} Agent;

typedef vector <vector<Agent>> AgentTable;
typedef vector<Agent> AgentList;


/*------------------------------------------------------------------------------------------------------------------*/
void get_commands(string& file_name, int& percent, int& segregate_time, int argc, char** argv)
{

	for (int i = 0; i < argc; i++) {
		string prefix = argv[i];
		if (prefix == "-f")
			file_name = argv[i + 1];
		else if (prefix == "-p")
			percent = atoi(argv[i + 1]);
		else if (prefix == "-s")
			segregate_time = atoi(argv[i + 1]);
	}
}



vector <char> get_input_from(char* file_name)
{
	vector <char> input_file_data;
	char temp_char = ' ';
	FILE *input;
	input = fopen(file_name, "r");
	while (!feof(input)) {
		fscanf(input, "%c", &temp_char);
		input_file_data.push_back(temp_char);
	}
	fclose(input);
	input_file_data.pop_back();

	return input_file_data;
}

void set_inputFile_in_table(AgentTable& agent_table, vector <char> input_file_data)
{
	Agent new_agent;
	int row = 0;
	int id_counter = 0;
	agent_table.push_back(vector<Agent>());
	for (int i = 0; i < input_file_data.size() - 1; i++) {
		if (input_file_data[i] != '\n') {
			new_agent.color = input_file_data[i];
			new_agent.id_number = ++id_counter;
			agent_table[row].push_back(new_agent);
		}
		else {
			row++;
			agent_table.push_back(vector<Agent>());
		}
	}
}


vector <char> neighbors_colors_of_this_agent(int row, int col, AgentTable& agent_table)
{
	vector <char> colors;
	int width = agent_table.size(), lenght = agent_table[0].size();
	if (row - 1 >= 0)
		colors.push_back(agent_table[row - 1][col].color);
	if (row + 1 < width)
		colors.push_back(agent_table[row + 1][col].color);
	if (col - 1 >= 0)
		colors.push_back(agent_table[row][col - 1].color);
	if (col + 1 < lenght)
		colors.push_back(agent_table[row][col + 1].color);
	return colors;
}

bool is_satisfied_this_agent(vector<char> neighbor_colors, char agent_color, int percentage)
{
	int counter = 0;
	for (int i = 0; i < neighbor_colors.size(); i++)
		if (neighbor_colors[i] == agent_color || neighbor_colors[i] == 'E')
			counter++;
	if (((double)counter / (double)neighbor_colors.size()) * 100.00 >= percentage)
		return true;
	else
		return false;
}

void update_agents_current_happiness_status(AgentTable& agent_table, int percentage)
{
	vector <char> neighbor_colors;
	for (int i = 0; i < agent_table.size(); i++) {
		for (int j = 0; j < agent_table[0].size(); j++) {
			if (agent_table[i][j].color == 'E') {
				agent_table[i][j].satisfaction = UNKNOWN;
				continue;
			}
			neighbor_colors = neighbors_colors_of_this_agent(i, j, agent_table);
			if (is_satisfied_this_agent(neighbor_colors, agent_table[i][j].color, percentage))
				agent_table[i][j].satisfaction = SATISFIED;
			else
				agent_table[i][j].satisfaction = UNSATISFIED;
		}
	}
}

void update_unsasisfied_and_empty_agent_lists(AgentTable agent_table, AgentList& unsatisfied, AgentList& empty)
{
	unsatisfied.clear();
	empty.clear();
	for (int i = 0; i < agent_table.size(); i++) {
		for (int j = 0; j < agent_table[0].size(); j++) {
			if (agent_table[i][j].satisfaction == UNSATISFIED)
				unsatisfied.push_back(agent_table[i][j]);
			if (agent_table[i][j].color == 'E')
				empty.push_back(agent_table[i][j]);
		}
	}
}

int find_index(Agent find_this, AgentList list)
{
	for (int i = 0; i < list.size(); i++)
		if (list[i].id_number == find_this.id_number)
			return i;
	return 0;
}

void remove_unwanted_ele(AgentList& unsatisfied, int origin, AgentList satis_yet)
{
	unsatisfied.erase(unsatisfied.begin() + origin);
	for (int i = 0; i < satis_yet.size(); i++) {
		int unsat_indax = find_index(satis_yet[i], unsatisfied);
		unsatisfied.erase(unsatisfied.begin() + unsat_indax);
	}

}

AgentList suitable_destinatins(AgentList unsatisfied, AgentList empty, int origin, AgentList satis_yet)
{
	AgentList suitable_destinatins;
	remove_unwanted_ele(unsatisfied, origin, satis_yet);
	suitable_destinatins.insert(suitable_destinatins.end(), unsatisfied.begin(), unsatisfied.end());
	suitable_destinatins.insert(suitable_destinatins.end(), empty.begin(), empty.end());
	return suitable_destinatins;
}

int random_number_upto(int max)
{
	srand(time(0));
	return rand() % max;
}

bool find_location(Agent agent, AgentTable agent_table, int& x, int&y)
{
	for (int i = 0; i < agent_table.size(); i++) {
		for (int j = 0; j < agent_table[0].size(); j++) {
			if (agent_table[i][j].id_number == agent.id_number) {
				x = i,
					y = j;
				return true;
			}
		}
	}
	return false;
}

void replace(Agent origin_agent, Agent dest_agent, AgentTable& agent_table)
{
	int origin_x, origin_y, dest_x, dest_y;
	if (find_location(origin_agent, agent_table, origin_x, origin_y) && find_location(dest_agent, agent_table, dest_x, dest_y)) {
		agent_table[origin_x][origin_y] = dest_agent;
		agent_table[dest_x][dest_y] = origin_agent;
	}
}

void jump_randomly(AgentTable& agent_table, AgentList unsatisfied, AgentList empty)
{
	AgentList satis_yet;
	for (int unsat_index = 0; unsat_index < unsatisfied.size(); unsat_index++) {
		AgentList dest_agents = suitable_destinatins(unsatisfied, empty, unsat_index, satis_yet);
		int random_index = random_number_upto(dest_agents.size());
		Agent rand_dest_agent = dest_agents[random_index];
		replace(unsatisfied[unsat_index], rand_dest_agent, agent_table);
		satis_yet.push_back(unsatisfied[unsat_index]);
	}
}



void update_data(AgentTable& table, AgentList& unsatisfied, AgentList& empty, int percentage)
{
	update_agents_current_happiness_status(table, percentage);
	update_unsasisfied_and_empty_agent_lists(table, unsatisfied, empty);
}

int num_of_unsatified_agants(AgentTable& agent_table)
{
	int num_of_unsatisfid = 0;
	for (int i = 0; i < agent_table.size(); i++) {
		for (int j = 0; j < agent_table[0].size(); j++)
			if (agent_table[i][j].satisfaction == UNSATISFIED)
				num_of_unsatisfid++;
	}
	return num_of_unsatisfid;
}

void check_best_table(AgentTable agent_table, AgentTable& best_table)
{
	int a = num_of_unsatified_agants(agent_table);
	int b = num_of_unsatified_agants(best_table);
	if (a < b)
		best_table = agent_table;

}

void segregate(AgentTable& agent_table, int percentage, int segregate_times)
{
	int counter = 0;
	AgentList unsatisfied, empty;
	update_data(agent_table, unsatisfied, empty, percentage);
	AgentTable best_table = agent_table;
	int unsat_num_after_jump = 1;
	int unsat_num_before_jump = unsatisfied.size();

	if (segregate_times == TILL_GENERAL_SATISFACTION)
		segregate_times = BIG_NUMBER;

	while (counter < segregate_times && unsatisfied.size() != 0) {
		do {
			unsat_num_before_jump = unsatisfied.size();
			jump_randomly(agent_table, unsatisfied, empty);
			update_data(agent_table, unsatisfied, empty, percentage);
			unsat_num_after_jump = unsatisfied.size();
		} while (unsat_num_before_jump < unsat_num_after_jump);

		check_best_table(agent_table, best_table);
		counter++;
	}
	agent_table = best_table;
}



void print_in_stdout(AgentTable& agent_table)
{
	cout << num_of_unsatified_agants(agent_table) << endl;
	for (int i = 0; i < agent_table.size(); i++) {
		for (int j = 0; j < agent_table[0].size(); j++)
			cout << agent_table[i][j].color;
		cout << endl;
	}
}

void print_in_ppmfile(AgentTable& agent_table)
{
	int r, b, g;
	FILE* output;
	if (!fopen("output.ppm", "w")) {
		fprintf(output, "%s\n%ld %ld\n%d\n", "P3", agent_table.size(), agent_table[0].size(), MAX_PIX_VAL);
		for (int i = 0; i < agent_table.size(); i++) {
			for (int j = 0; j < agent_table[0].size(); j++) {
				if (agent_table[i][j].color == 'E') {
					r = MAX_PIX_VAL;
					g = MAX_PIX_VAL;
					b = MAX_PIX_VAL;
				}
				else if (agent_table[i][j].color == 'B') {
					r = 0;
					g = 0;
					b = MAX_PIX_VAL;
				}
				else if (agent_table[i][j].color == 'R') {
					r = MAX_PIX_VAL;
					g = 0;
					b = 0;
				}
				fprintf(output, "%d   %d   %d   ", r, g, b);
			}
			fprintf(output, "%c", '\n');

		}
		fclose(output);
	}
}

void print_outputs(AgentTable& agent_table)
{
	print_in_stdout(agent_table);
	print_in_ppmfile(agent_table);
}

int main(int argc, char** argv)
{

	AgentTable agent_table;
	int percentage = 30, segregate_times = TILL_GENERAL_SATISFACTION;
	string file_name = "map.txt";
	get_commands(file_name, percentage, segregate_times, argc, argv);
	set_inputFile_in_table(agent_table, get_input_from((char*)file_name.c_str()));
	segregate(agent_table, percentage, segregate_times);
	print_outputs(agent_table);
}