#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <map>
using namespace std;




int main()
{
    map<string,int> mymap;
    mymap.insert({"hi",1});
    cout << mymap["hii"] << endl;
    
}