//IN THE NAME OF GOD // 
//Fatemeh Shahhosseini _ object oriented programing _ train/passenger/station\time //
#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
using namespace std;
const int RESET_TIME = 0;
const int EMPTY_LIST = 0;
const int TILL_ARRIVE_EVERY_PASSENGER = 200;
enum Train_status { resting, moving };
enum Passenger_status { on_train, in_station, suspended, arrived };
enum Location { train, station };

struct Cur_pas_location {
	Passenger_status status;
	string location_name_id;
};

struct Passenger_info {
	Cur_pas_location location;
	int spent_money;
};

struct Train_info {
	Train_status status;
	int estimated_time;
	string next_station_name;
	int passenger_count;
};
class Passenger;
class Train;
class Station;
bool is_hammasir_train(Train trn, Station* pas_origin_st, Station* pas_dest_st);
bool has_everyone_arrived(vector <Passenger> pasngers);
void update_detrained_passengers_location(vector<Passenger*> token_pasngrs_list, string new_station_name);

class Station {
public:
	Station() {};
	Station(string name, int price) {
		station_name = name;
		choco_price = price;
	}
	string get_name() { return station_name; };
	int get_chocolate_price() { return choco_price; };
	vector <int> get_pas_list() { return in_station_pasngrs_list; };

	int find_index_in_list(int missed_pas, vector<int> pas_list) {
		for (unsigned index = 0; index < pas_list.size(); index++)
			if (pas_list[index] == missed_pas)
				return index;
	}
	void add_new_passengers(vector <int> new_passengers) {
		for (int i = 0; i < new_passengers.size(); i++)
			in_station_pasngrs_list.push_back(new_passengers[i]);
	}
	void delete_passenger(int leaved_pas) {
		int index = find_index_in_list(leaved_pas, in_station_pasngrs_list);
		in_station_pasngrs_list.erase(in_station_pasngrs_list.begin() + index);
	}
private:
	string station_name;
	int choco_price;
	vector <int> in_station_pasngrs_list;
};

class Train {
public:
	Train(int id, Station* start, Station* end, int travel_time, int rest_time) {
		train_id = id; start_st = start; end_st = end;
		travel_t = travel_time; rest_t = rest_time;
		status = resting;
		estimated_time = rest_time;
		token_pasngrs_list;
	}
	Train_status get_status() { return status; };
	Train_info get_info() {
		Train_info info{ status,estimated_time,end_st->get_name(),token_pasngrs_list.size() };
		return info;
	}
	int get_id() { return train_id; };
	vector<Passenger*> get_token_passengers_list() { return token_pasngrs_list; };
	string get_dest_station_name() { return end_st->get_name(); };
	string get_start_station_name() { return start_st->get_name(); };
	int get_estimated_time() { return estimated_time; }
	void change_status() {
		status = (status == resting) ? moving : resting;
	}
	void redirection() {
		Station* temp_st = start_st;
		start_st = end_st;
		end_st = temp_st;
	}
	void decrease_estimated_time() {
		estimated_time--;
	}
	void update_estimated_time() {
		estimated_time = (status == moving) ? travel_t : rest_t;
	}
	void detrain_passengers() {
		token_pasngrs_list.clear();
	}
	void take_passenger(Passenger* new_pas) {
		token_pasngrs_list.push_back(new_pas);
	}
private:
	int train_id;
	int travel_t, rest_t, estimated_time;
	Station *start_st, *end_st;
	Train_status status;
	vector <Passenger*> token_pasngrs_list;
};


class Passenger {
public:
	Passenger(int id, int interest_rate, vector <Station*> stations) {
		passenger_id = id;
		passenger_interest_rate = interest_rate;
		cur_loc.location_name_id = stations[0]->get_name();
		cur_loc.status = in_station;
		passenger_dests = stations;
	}
	int get_rate() { return passenger_interest_rate; };
	int get_id() { return passenger_id; };
	int get_best_train_id() { return best_train_id; };
	Passenger_status get_status() { return cur_loc.status; };
	void update_next_dest_station() { passenger_dests.erase(passenger_dests.begin()); };
	void increase_wait_time() { wait_time++; };
	void reset_wait_time() { wait_time = RESET_TIME; };
	void change_cur_loc(string new_location_name) {
		cur_loc.status = (cur_loc.status == on_train) ? in_station : on_train;
		cur_loc.location_name_id = new_location_name;
	}
	vector<Train> find_hammasir_trains(vector <Train> trns) {
		vector <Train> hammasir_trns;
		for (Train trn : trns)
			if (is_hammasir_train(trn, passenger_dests[0], passenger_dests[1]))
				hammasir_trns.push_back(trn);
		return hammasir_trns;
	}
	void update_spent() {
		int	new_expense = wait_time * passenger_dests[0]->get_chocolate_price() * passenger_interest_rate;
		spent = +new_expense;
	}
	void update_best_train(vector <Train> hammasir_trns) {
		int least_id = (hammasir_trns[0]).get_id();
		for (auto trn : hammasir_trns)
			least_id = (trn.get_id() < least_id) ? trn.get_id() : least_id;
		best_train_id = least_id;
	}
	void update_cur_location(Location st_or_trn, string name_id) {
		int final_dest_index = passenger_dests.size() - 1;
		if (st_or_trn == train)
			cur_loc.status = on_train;
		else if (st_or_trn == station)
			if (name_id == passenger_dests[final_dest_index]->get_name())
				cur_loc.status = arrived;
			else
				cur_loc.status = in_station;
		cur_loc.location_name_id = name_id;
	}
	void change_status(Passenger_status new_status) { cur_loc.status = new_status; };
	Cur_pas_location get_current_location() { return cur_loc; };
	Passenger_info get_general_info() {
		Passenger_info info{ cur_loc,spent };
		return info;
	}
private:
	int passenger_id;
	int passenger_interest_rate;
	int spent;
	int wait_time;
	int best_train_id;
	Cur_pas_location cur_loc;
	vector <Station*> passenger_dests;
};



bool is_hammasir_train(Train trn, Station* pas_origin_st, Station* pas_dest_st)
{
	if (trn.get_start_station_name() == pas_origin_st->get_name() &&
		trn.get_dest_station_name() == pas_dest_st->get_name() &&
		trn.get_status() == resting)
		return true;
	else
		return false;
}
bool has_everyone_arrived(vector <Passenger> pasngers) {
	for (Passenger p : pasngers)
		if (p.get_current_location().status != arrived)
			return false;
	return true;
}
void update_detrained_passengers_location(vector<Passenger*> token_pasngrs_list, string new_station_name) {
	for (int i = 0; i < token_pasngrs_list.size(); i++)
		token_pasngrs_list[i]->update_cur_location(station, new_station_name);
}
vector <int> extract_ids(vector <Passenger*> pas) {
	vector <int> vec;
	for (int i = 0; i < pas.size(); i++) {
		vec.push_back(pas[i]->get_id());
	}
	return vec;
}


class Shabihsazi {
public:
	bool add_passenger(int id, int interest_rate, vector<Station*> dests) {
		Passenger new_pas(id, interest_rate, dests);
		pasngrs.push_back(new_pas);
		dests[0]->add_new_passengers(vector <int> {new_pas.get_id()});
		return true;
	}
	bool add_station(string stat_name, int choco_price) {
		Station new_stat(stat_name, choco_price);
		stats.push_back(new_stat);
		return true;
	}
	bool add_train(int id, Station* origin, Station* dest, int travel_time, int cool_time) {
		Train new_trn(id, origin, dest, travel_time, cool_time);
		trns.push_back(new_trn);
		return true;
	}
	bool advance_time(int how_much_time) {
		int time_counter = 0;
		while (time_counter < how_much_time && has_everyone_arrived(pasngrs) == false) {
			advance_time_for_trains();
			advance_time_for_in_satation_passengers();
			time_counter++;
		}
		return true;
	}
	string show_pas_info(int pas_id) {
		Passenger* pas = find_passenger_by_id(pas_id);
		stringstream output;
		string status, trn_or_st = "station";
		Passenger_info info = pas->get_general_info();
		if (info.location.status == on_train) {
			status = "on train";
			trn_or_st = "train";
		}
		else if (info.location.status == in_station || info.location.status == suspended)
			status = "in station";
		else if (info.location.status == arrived)
			status = "arrived";
		output << "status : " << status << "\n"
			<< "spent : " << info.spent_money << "\n"
			<< "current " << trn_or_st << " " << info.location.location_name_id << "\n";
		return output.str();
	}

	string show_trn_info(int trn_id) {
		stringstream output;
		string status;
		Train* trn = find_train_by_id(trn_id);
		Train_info info = trn->get_info();
		if (info.status == moving)
			status = "moving";
		else
			status = "resting";
		output << "status : " << status << "\n"
			<< "estimated remaining time : " << ++info.estimated_time << "\n"
			<< "next station : " << info.next_station_name << "\n"
			<< "passenger count : " << info.passenger_count << "\n";
		return output.str();
	}
	void advance_time_for_trains() {
		for (unsigned i = 0; i < trns.size(); i++) {
			if (trns[i].get_estimated_time() == 0) {
				if (trns[i].get_status() == moving) {
					Station* cur_st = find_station_by_name(trns[i].get_dest_station_name());
					update_detrained_passengers_location(trns[i].get_token_passengers_list(), cur_st->get_name());
					trns[i].detrain_passengers();
					vector <int> new_pas_ids = extract_ids(trns[i].get_token_passengers_list());
					cur_st->add_new_passengers(new_pas_ids);
					trns[i].redirection();
				}
				trns[i].change_status();
				trns[i].update_estimated_time();
			}
			trns[i].decrease_estimated_time();
		}
	}
	void advance_time_for_in_satation_passengers() {
		for (unsigned i = 0; i < stats.size(); i++) {
			vector <int> pas_id_list = stats[i].get_pas_list();
			for (unsigned j = 0; j < pas_id_list.size(); j++) {
				Passenger* pas = find_passenger_by_id(pas_id_list[j]);
				if (pas->get_status() == suspended) {
					int best_train_id = pas->get_best_train_id();
					pas->update_cur_location(train, to_string(best_train_id));
					pas->update_next_dest_station();
					find_train_by_id(best_train_id)->take_passenger(pas);
					stats[i].delete_passenger(pas->get_id());
				}
				else {
					vector <Train> hammasir_trains = pas->find_hammasir_trains(trns);
					if (hammasir_trains.size() == EMPTY_LIST)
						pas->increase_wait_time();
					else {
						pas->update_best_train(hammasir_trains);
						pas->change_status(suspended);
						pas->update_spent();
					}
				}
			}
		}
	}
	Station* find_station_by_name(string missed_stat_name) {
		for (int i = 0; i < stats.size(); i++)
			if (stats[i].get_name() == missed_stat_name)
				return &stats[i];
		cout << "This train doesn't exist.\n";
		abort();
	}
	Train* find_train_by_id(int missed_train_id) {
		for (int i = 0; i<trns.size(); i++)
			if (trns[i].get_id() == missed_train_id)
				return &trns[i];
		cout << "This train doesn't exist.\n";
		abort();
	}
	Passenger* find_passenger_by_id(int missed_pas_id) {
		for (int i = 0; i<pasngrs.size(); i++)
			if (pasngrs[i].get_id() == missed_pas_id)
				return &pasngrs[i];
		cout << "This passenger doesn't exist.\n";
		abort();
	}
private:
	vector <Train> trns;
	vector <Passenger> pasngrs;
	vector <Station> stats;
};


int main()
{
	Shabihsazi shabihsazi;
	string command, line, output_str;
	int trn_id = 0, pas_id = 0;

	while (cin >> command) {
		if (command == "add_passenger") {
			int interest_rate;
			string dest;
			vector <Station*> dests;
			stringstream line_buf;
			getline(cin, line);
			line_buf.str(line);
			line_buf >> interest_rate;
			while (line_buf >> dest)
				dests.push_back(shabihsazi.find_station_by_name(dest));
			pas_id++;
			if (shabihsazi.add_passenger(pas_id, interest_rate, dests))
				cout << "OK\n";
		}
		else if (command == "add_train") {
			trn_id++;
			string origin_name, dest_name;
			int travel_time, cool_time;
			cin >> origin_name >> dest_name >> travel_time >> cool_time;
			Station* origin = shabihsazi.find_station_by_name(origin_name);
			Station* dest = shabihsazi.find_station_by_name(dest_name);
			if (shabihsazi.add_train(trn_id, origin, dest, travel_time, cool_time))
				cout << "OK\n";
		}
		else if (command == "add_station") {
			int choco_price;
			string name;
			cin >> name >> choco_price;
			if (shabihsazi.add_station(name, choco_price))
				cout << "OK\n";
		}
		else if (command == "advance_time") {
			int how_much_time;
			cin >> how_much_time;
			if (shabihsazi.advance_time(++how_much_time))
				cout << "OK\n";
		}
		else if (command == "finish") {
			if (shabihsazi.advance_time(TILL_ARRIVE_EVERY_PASSENGER))
				cout << "OK\n";
		}
		else if (command == "show_passenger_info") {
			int passenger_id;
			cin >> passenger_id;
			output_str = shabihsazi.show_pas_info(passenger_id);
			cout << output_str;
		}
		else if (command == "show_train_info") {
			int train_id;
			cin >> train_id;
			output_str = shabihsazi.show_trn_info(train_id);
			cout << output_str;
		}
	}
}

