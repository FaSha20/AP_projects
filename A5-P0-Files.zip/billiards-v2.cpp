#include <iostream>
#include <cstdlib>
using namespace std;

class Ball;

class Table
{
public:
    Table(double w, double h);
    bool contains_point(double x, double y);
    void reflect(Ball *b);

private:
    double width;
    double height;
};

class Ball
{
public:
    Ball(double _x, double _y, double _vx, double _vy, Table *t);
    void move(double dt);
    double get_x() { return x; }
    double get_y() { return y; }
    double get_vx() { return vx; }
    double get_vy() { return vy; }
    void set_location(double _x, double _y);
    void set_speed(double _vx, double _vy);

private:
    double x;
    double y;
    double vx;
    double vy;
    Table *table;
};

Table::Table(double w, double h)
{
    cout << "Table constructor called" << endl;
    if (w <= 0 || h <= 0)
        abort();
    width = w;
    height = h;
}

bool Table::contains_point(double x, double y)
{
    cout << "Table::contains_point called" << endl;
    return x >= 0 && x < width && y >= 0 && y < height;
}

void Table::reflect(Ball *b)
{
    cout << "Table::reflect called" << endl;
    double x = b->get_x();
    double y = b->get_y();
    double vx = b->get_vx();
    double vy = b->get_vy();

    while (!contains_point(x, y))
    {
        if (x < 0)
        {
            x = -x;
            vx = -vx;
        }
        if (x >= width)
        {
            x = 2 * width - x;
            vx = -vx;
        }
        if (y < 0)
        {
            y = -y;
            vy = -vy;
        }
        if (y >= height)
        {
            y = 2 * height - y;
            vy = -vy;
        }
    }
    b->set_location(x, y);
    b->set_speed(vx, vy);
}

Ball::Ball(double _x, double _y, double _vx, double _vy, Table *t)
{
    cout << "Ball constructor called" << endl;
    table = t;
    set_location(_x, _y);
    set_speed(_vx, _vy);
    cout << "Initial position is: (" << x << ',' << y << ')' << endl;
}

void Ball::set_location(double _x, double _y)
{
    cout << "Ball::set_location called with (" << _x << ',' << _y << ')' << endl;
    if (!table->contains_point(_x, _y))
        abort();
    x = _x;
    y = _y;
}

void Ball::set_speed(double _vx, double _vy)
{
    cout << "Ball::set_speed called with (" << _vx << ',' << _vy << ')' << endl;
    vx = _vx;
    vy = _vy;
}

void Ball::move(double dt)
{
    cout << "Ball::move called" << endl;
    x += vx * dt;
    y += vy * dt;

    if (!table->contains_point(x, y))
        table->reflect(this);
    cout << "New position is: (" << x << ',' << y << ')' << endl;
}

// b.move(1);

int main()
{
    Table t(100, 50);
    Ball b(10, 20, 25, 5, &t);
    b.move(10);
}