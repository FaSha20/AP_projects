#include "documents.hpp"

void Document::notify_observers()
{
    for(int i = 0;i < observers.size();i++)
        observers[i]->update(this);
}

bool Document:: is_confirmed()
{
    if(status == confirmed) 
        return true;
    else 
        return false;
}
string set_tab(int how_many_tabs)
{
    stringstream ss;
    for(int i = 0;i < how_many_tabs;i++)
        ss << '\t';
    return ss.str();
}

string Form ::get_info(int tab_counter)
{
    stringstream buf;
    buf << set_tab(tab_counter) << "Name: " << name << endl;
    buf << set_tab(tab_counter) << "Content: " << content << endl;
    return buf.str();
}

bool Permition::do_i_need(string document_name)
{
    for(string required_doc_name:requirements_names)
        if(required_doc_name == document_name)
            return true;
    return false;
}  

void Permition::find_organ_signature(string sign_type,
                string manager_name,string ceo_name,string organ_name)
{
    if(sign_type == ORGAN_SIGN)
        signature = organ_name;
    else if(sign_type == MANAGER_SIGN)
        signature = manager_name;
    else if(sign_type == CEO_SIGN)
        signature = ceo_name;
}

void Permition::set_requirements_names(string requs)
{
    stringstream spliter(requs);
    string document_name;
    while (getline(spliter,document_name,'-'))
    {
        requirements_names.push_back(document_name);
    }
}

void Permition::become_observer_of_its_requirements()
{
    for(int i = 0;i < requirements.size();i++){
        requirements[i]->add_observer(this);
    }
}

void Permition::update(Document* observable)
{
    unmet_requirements.erase(remove(unmet_requirements.begin()
        ,unmet_requirements.end(),observable),unmet_requirements.end());
    if(unmet_requirements.size() == 0){
        notify_observers();
        change_to_confirmed();
        if(am_i_final_permition)
            cout << get_info();
    }
}

int find_index(vector<Document*> vec,Document* element)
{
    for(int i = 0 ;i < vec.size(); i++)
        if(vec[i] == element)
            return i;
    return 0;
}

int find_index_by_name(vector<Document*> vec,string element_name)
{
    for(int i = 0 ;i < vec.size(); i++)
        if(vec[i]->get_name() == element_name)
            return i;
    return 0;
}

void Permition::change_arrengment_of_requs()
{
    for( int index = 0 ; index < requirements_names.size();index++){
        if(requirements[index]->get_name() != requirements_names[index]){
            Document* proper_doc = requirements[find_index_by_name(requirements,requirements_names[index])];
            Document* temp = requirements[index];
            requirements[index] = proper_doc;
            requirements[find_index(requirements,proper_doc)] = temp;
        }
    }
}

string Permition ::get_info(int tab_counter )
{
    change_arrengment_of_requs();
    stringstream buf;
    int counter = 0;
    buf << set_tab(tab_counter) << "Name: " << name << endl;
    buf << set_tab(tab_counter) <<"This permit consist of: {\n" ;
    for(Document* doc : requirements){
        buf << set_tab(tab_counter + 1) << "#" << ++counter << endl;
        buf <<  doc->get_info(tab_counter + 1);
    }
    buf << set_tab(tab_counter) << "}" << endl;
    buf << set_tab(tab_counter) << "Signature: " << signature << endl;

        
    return buf.str();
}
