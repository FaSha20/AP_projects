// IN THE NAME OF GOD
//Fatemeh Shahhosseini - 1400/3/1
//AP6 poject : permitMaker (inheritance & polymorfism)
#include <iostream>
#include "documents.hpp"
#include "read_file.hpp"
#include "process.hpp"
using namespace std;

int main()
{
    Doc_lists lists;
    vector<string>file_addresses = read_file_addresses();
    Process data_handeler;
    lists = data_handeler.set_all_lists(file_addresses);    
    data_handeler.set_relation_between_docs();
    data_handeler.command_checking();
    data_handeler.free_allocated_memories();
    return 0;
}