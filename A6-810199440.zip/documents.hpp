#ifndef _DOCUMENTS_H
#define _DOCUMENTS_H

#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>
#include "documents.hpp"
#define MANAGER_SIGN "m"
#define CEO_SIGN "c"
#define ORGAN_SIGN "o"
#define FORMS_FIRST_LETTER 'f'
#define PERMITS_FIRST_LETTER 'p'
using namespace std;

enum Status{confirmed,unconfirmed};
class Permition;

class Document{
public:
    Document(string _name){name = _name, status = unconfirmed;};
    //~Document(){cout << "delete memory!\n";};
    void add_observer(Permition* new_obs){observers.push_back(new_obs);};
    void notify_observers();
    void change_to_confirmed(){status = confirmed;};
    bool is_confirmed();
    string get_name(){return name;};
    virtual string get_info(int tab_counter = 0) = 0;
    vector<Permition*> observers;
protected:
    string name;
    Status status;
};

class Form : public Document{
public:
    Form(string _name,string _content): Document(_name){content = _content;};
    string get_info(int tab_counter = 0);
private:
    string content;
};

class Permition : public Document{
public:
    Permition(string _name,bool is_final): Document(_name)
        {am_i_final_permition = is_final;};
    void set_requirements_names(string requs);
    void update(Document* observable);
    void find_organ_signature(string sign_t,string m,string c,string o);
    bool do_i_need(string document_name);
    void add_to_my_requirements(Document* found_requ)
        {requirements.push_back(found_requ);};
    void become_observer_of_its_requirements();
    void set_unmet_requirements(){unmet_requirements = requirements;};
    void change_arrengment_of_requs();
    string get_info(int tab_counter = 0);
    bool am_i_final_permition;
    
private:
    vector <string> requirements_names;
    vector<Document*> requirements ;
    vector<Document*> unmet_requirements ;   
    string signature;
};


#endif //_DOCUMENTS_H