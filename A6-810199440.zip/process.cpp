#include <iostream>
#include "process.hpp"
#include <vector>
using namespace std;

Doc_lists Process:: set_all_lists(vector<string>file_addresses)
{
    set_permitions(file_addresses[ORGANS]);
    set_forms(file_addresses[FORMS]);
    set_general_list();
    find_permits_requirements();
   // for(auto i : permitions[0]->requirements)
    //  cout << i->get_name() << i->get_info()<< endl;
    return Doc_lists{general_list,permitions,forms};
}

Permition* make_permition(vector<string> file_data_list,bool is_final_permit)
{
    string organ_name,manager_name,ceo_name;
    string sign_type,final_prmit_name,requirements;
    organ_name = file_data_list[0];       sign_type = file_data_list[1];
    final_prmit_name =file_data_list[2]; requirements=file_data_list[3];
    manager_name = file_data_list[4];      ceo_name = file_data_list[5]; 
    Permition* new_permit= new Permition(final_prmit_name,is_final_permit);
    new_permit->set_requirements_names(requirements);
    new_permit->find_organ_signature(sign_type,manager_name,ceo_name,
                                    organ_name);
    return new_permit;
}

Form* make_form(vector<string> file_data_list)
{
    string form_name = file_data_list[0];
    string content = file_data_list[1];
    Form* new_form = new Form(form_name,content);
    return new_form;
}

void Process::set_permitions(string organs_file_address)
{
    fstream input(organs_file_address);
    string line,temp_word;
    int permit_counter = 0;
    bool is_final_permit;
    input.ignore(200,'\n');
    while (getline(input,line))
    {
        is_final_permit = false;
        stringstream check(line);
        vector<string> file_data_list;
        while(getline(check, temp_word, DELIMETER))
            file_data_list.push_back(temp_word);
       
        if(permit_counter == 0)
            is_final_permit = true;
        Permition* new_pemit = make_permition(file_data_list,is_final_permit);
        permitions.push_back(new_pemit);  
        permit_counter++;
    }
}

void Process::set_forms(string forms_file_address)
{
    fstream input(forms_file_address);
    string line,temp_word;
    input.ignore(200,'\n');
    while (getline(input,line))
    {
        stringstream check(line);
        vector<string> file_data_list;
        while(getline(check, temp_word, DELIMETER))
            file_data_list.push_back(temp_word);
           
        Form* new_form = make_form(file_data_list);
        forms.push_back(new_form);  
    }
}

void Process::set_general_list()
{
    for(int i = 0;i < forms.size(); i++)
        general_list.push_back(forms[i]);
    for(int j = 0;j < permitions.size(); j++)
        general_list.push_back(permitions[j]);
}

void Process::find_permits_requirements()
{
    for(int p = 0;p < permitions.size();p++)
    {
        for(int g = 0;g < general_list.size();g++){
            if(permitions[p]-> do_i_need(general_list[g]->get_name()))
                permitions[p]-> add_to_my_requirements(general_list[g]);
        }
        permitions[p]-> set_unmet_requirements();
    }
}

Form* Process::find_form_by_name(string form_name)
{
    for(int i = 0;i < forms.size();i++){
        if(forms[i]->get_name() == form_name)
            return forms[i];
    }
    return NULL;
}

void Process::set_relation_between_docs()
{
    for(int p = 0;p < permitions.size();p++)
       permitions[p]-> become_observer_of_its_requirements();
}

void Process:: command_checking()
{
    string command,form_name;
    while (cin >> command && command == "Confirm")
    {
        cin >> form_name;
        Form* found_form = find_form_by_name(form_name);
        if(!found_form->is_confirmed()){
            found_form->change_to_confirmed();
            found_form-> notify_observers();
        }
    }
}

void Process:: free_allocated_memories()
{
    for(int g = 0;g < general_list.size(); g++){
        delete general_list[g];
    }
}
