#include <iostream>
#include "read_file.hpp"
using namespace std;

vector<string> read_file_addresses()
{
    vector<string> file_addresses{2};
    cin >> file_addresses[ORGANS] >> file_addresses[FORMS];
    return file_addresses;
}

