#ifndef _PROCESS_H
#define _PROCESS_H

#include <iostream>
#include "documents.hpp"
#include "process.hpp"
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#define DELIMETER ','
#define ORGANS 0
#define FORMS  1
using namespace std;

struct Doc_lists
{
    vector<Document*> all_docs;
    vector<Permition*> permits;
    vector<Form*> forms;
};

class Process{
public:
    Doc_lists set_all_lists(vector<string> file_addresses);
    void command_checking();
    void find_permits_requirements();
    Form* find_form_by_name(string form_name);
    void set_relation_between_docs();
    void free_allocated_memories();
private:
    void set_permitions(string organs_file_address);
    void set_forms(string forms_file_address);
    void set_general_list();
    vector<Permition*> permitions;
    vector<Form*> forms;
    vector<Document*> general_list;
};



#endif //_PROCESS_H