#ifndef _READ_FILE_H
#define _READ_FILE_H

#include <iostream>
#include "documents.hpp"
#include "read_file.hpp"
#include "process.hpp"
#include <vector>
#include <string>

using namespace std;



vector<string> read_file_addresses();

#endif //_READ_FILE_H